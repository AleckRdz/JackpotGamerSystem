<footer>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <p><a href="https://www.facebook.com/Jackpotgamermx">Jackpotgamermx</a>® 2023 - Ciudad Victoria, Tamps. - Todos los derechos reservados.

                    <!-- Design: <a title="CSS Templates" rel="sponsored" href="https://templatemo.com/page/1" target="_blank">TemplateMo</a> Distribution: <a title="CSS Templatesss" rel="sponsored" href="https://themewagon.com" target="_blank">ThemeWagon</a></p> -->
            </div>
        </div>
    </div>
</footer>

<!-- Scripts -->
<!-- Bootstrap core JavaScript -->
<!-- <script src="vendor/jquery/jquery.min.js"></script> -->
<script src="vendor/bootstrap/js/bootstrap.min.js"></script>

<script src="assets/js/isotope.min.js"></script>
<script src="assets/js/owl-carousel.js"></script>

<script src="assets/js/tabs.js"></script>
<script src="assets/js/popup.js"></script>
<script src="assets/js/custom.js"></script>

<script src="admin/js/notifications.js"></script>
</body>

</html>